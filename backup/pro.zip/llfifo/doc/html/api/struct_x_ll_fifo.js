var struct_x_ll_fifo =
[
    [ "Axi4BaseAddress", "struct_x_ll_fifo.html#a455c634fb80553cecfcba0845eb99937", null ],
    [ "BaseAddress", "struct_x_ll_fifo.html#a458030a162537427b617cbb204a701fd", null ],
    [ "Datainterface", "struct_x_ll_fifo.html#a9e2342496ea8183c012567d7c89851b3", null ],
    [ "IsReady", "struct_x_ll_fifo.html#abe388bb422699248b26a9d76652474b1", null ],
    [ "RxStreamer", "struct_x_ll_fifo.html#a456fbf87ce23b1334c67b386722b1434", null ],
    [ "TxStreamer", "struct_x_ll_fifo.html#a13363fb4d5d45a5725b7427b36c44817", null ]
];