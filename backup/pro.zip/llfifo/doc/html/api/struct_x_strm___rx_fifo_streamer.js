var struct_x_strm___rx_fifo_streamer =
[
    [ "FifoInstance", "struct_x_strm___rx_fifo_streamer.html#ab278ceaef035943f8a3a8b85a8cab99d", null ],
    [ "FifoWidth", "struct_x_strm___rx_fifo_streamer.html#a3ad4cdd1ad14dcecfaf5f923850289fb", null ],
    [ "FrmByteCnt", "struct_x_strm___rx_fifo_streamer.html#a9fa74d02f4fa2607e78b11de059be837", null ],
    [ "GetLenFn", "struct_x_strm___rx_fifo_streamer.html#a01fa1cc2098388ac9371beb090c0c212", null ],
    [ "GetOccupancyFn", "struct_x_strm___rx_fifo_streamer.html#a8d552e42f58c3230de010178832b41b1", null ],
    [ "HeadIndex", "struct_x_strm___rx_fifo_streamer.html#a6321ab6bf1a1f3979c0771618a4aba7c", null ],
    [ "ReadFn", "struct_x_strm___rx_fifo_streamer.html#af3bfc974fd88c7b707edf680b3c9aed2", null ]
];