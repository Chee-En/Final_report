var struct_x_strm___tx_fifo_streamer =
[
    [ "FifoInstance", "struct_x_strm___tx_fifo_streamer.html#ac20fde8a3090fddfc01f8b2900fd9051", null ],
    [ "FifoWidth", "struct_x_strm___tx_fifo_streamer.html#a474cf91d66d43f716a34299d4ab9b9b2", null ],
    [ "GetVacancyFn", "struct_x_strm___tx_fifo_streamer.html#ab33212eea0a6327f2c6b1173510170a9", null ],
    [ "SetLenFn", "struct_x_strm___tx_fifo_streamer.html#aa315e740022ccc81ef9cccfe7c82022d", null ],
    [ "TailIndex", "struct_x_strm___tx_fifo_streamer.html#a265500391a387c5354a14fea79a1b446", null ],
    [ "WriteFn", "struct_x_strm___tx_fifo_streamer.html#abaed83d1259485a6deadbf4644b0be1b", null ]
];