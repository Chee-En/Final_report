var annotated =
[
    [ "XLlFifo", "struct_x_ll_fifo.html", "struct_x_ll_fifo" ],
    [ "XStrm_RxFifoStreamer", "struct_x_strm___rx_fifo_streamer.html", "struct_x_strm___rx_fifo_streamer" ],
    [ "XStrm_TxFifoStreamer", "struct_x_strm___tx_fifo_streamer.html", "struct_x_strm___tx_fifo_streamer" ]
];