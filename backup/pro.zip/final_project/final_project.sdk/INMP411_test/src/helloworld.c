#include "xparameters.h"
#include "xaxidma.h"
#include "xil_printf.h"

#define DMA_DEV_ID      XPAR_AXIDMA_0_DEVICE_ID
#define DDR_BASE_ADDR   XPAR_PS7_DDR_0_S_AXI_BASEADDR
#define RX_BUFFER_BASE  (DDR_BASE_ADDR + 0x1000000)
#define RX_BUFFER_SIZE  1024  // 單次收 1024 bytes (256 samples)

XAxiDma AxiDma;

int main() {
    xil_printf("=== INMP441 I2S DMA Receive (from tlaster_debug) ===\r\n");

    XAxiDma_Config *CfgPtr = XAxiDma_LookupConfig(DMA_DEV_ID);
    if (!CfgPtr) {
        xil_printf("DMA Lookup Failed\r\n");
        return XST_FAILURE;
    }

    if (XAxiDma_CfgInitialize(&AxiDma, CfgPtr) != XST_SUCCESS) {
        xil_printf("DMA Init Failed\r\n");
        return XST_FAILURE;
    }

    Xil_DCacheDisable();  // 關 cache 防止資料錯誤

    xil_printf("Starting DMA transfer...\r\n");

    if (XAxiDma_SimpleTransfer(&AxiDma, RX_BUFFER_BASE, RX_BUFFER_SIZE, XAXIDMA_DEVICE_TO_DMA) != XST_SUCCESS) {
        xil_printf("DMA transfer failed!\r\n");
        return XST_FAILURE;
    }

    int timeout = 100000000;
    while (XAxiDma_Busy(&AxiDma, XAXIDMA_DEVICE_TO_DMA) && timeout--) {
        if ((timeout % 10000000) == 0) xil_printf("...DMA still busy (%d)\r\n", timeout);
    }


    if (timeout <= 0) {
        xil_printf("❌ DMA Timeout! tlaster_debug 沒送 tvalid/tlast\r\n");
    } else {
        xil_printf("✅ DMA done. Dumping 32 samples:\r\n");
    }

		xil_printf("DMA done. Dumping 32 samples:\r\n");

		u32 *data = (u32 *)RX_BUFFER_BASE;
		for (int i = 0; i < 32; i++) {
			xil_printf("Sample[%2d] = 0x%08x\r\n", i, data[i]);
		}

    xil_printf("Done.\r\n");
    return 0;
}
